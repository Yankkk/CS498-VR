﻿using UnityEngine;
using System.Collections;

public class AddLine : MonoBehaviour {

    // Use this for initialization

    public Color c1 = Color.yellow;
    public Color c2 = Color.red;
	void Start () {
       
        LineRenderer lineRenderer = gameObject.AddComponent<LineRenderer>();
        lineRenderer.material = new Material(Shader.Find("Particles/Additive"));
        lineRenderer.SetColors(c1, c2);
        lineRenderer.SetWidth(0.2F, 0.2F);
        lineRenderer.SetVertexCount(7);
        Vector3[] points = new Vector3[7];

        points[0] = GameObject.Find("Alkaid").transform.position;
        points[1] = GameObject.Find("Mizar").transform.position;
        points[2] = GameObject.Find("Alioth").transform.position;
        points[3] = GameObject.Find("Megrez").transform.position;
        points[4] = GameObject.Find("Phecda").transform.position;
        points[5] = GameObject.Find("Merak").transform.position;
        points[6] = GameObject.Find("Dubhe").transform.position;

        lineRenderer.SetPositions(points);
    }
	
	// Update is called once per frame
	void Update () {
	
	}
}
