﻿using UnityEngine;
using System.Collections;

public class GuiText : MonoBehaviour {
    GameObject star;
    GuiText pos;
	// Use this for initialization
	void Start () {
        star = GameObject.Find("Alkaid");
        pos = star.GetComponent<GuiText>();
	}
	
	// Update is called once per frame
	void Update () {
        pos.transform.position = new Vector3(0.5f, 0.5f, 0);
	}
}
